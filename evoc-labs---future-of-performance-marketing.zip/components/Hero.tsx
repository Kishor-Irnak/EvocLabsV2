import React, { useRef, useState, useEffect } from 'react';
import { Play, ArrowRight, LayoutDashboard, BarChart2, Zap, Target, FileText, Link2, Search, Calendar, ChevronDown, MoreHorizontal, ArrowUpRight } from 'lucide-react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const initialChartData = [
  { name: 'Jun 12', value: 8.5 },
  { name: 'Jun 14', value: 9.2 },
  { name: 'Jun 16', value: 8.8 },
  { name: 'Jun 18', value: 9.8 },
  { name: 'Jun 20', value: 9.1 },
  { name: 'Jun 22', value: 9.5 },
  { name: 'Jun 24', value: 10.15 },
];

const keywords = [
  "online payment processing",
  "secure transactions",
  "online transaction platform",
  "online shopping payments",
  "e-commerce payment gateway",
  "b2b payment processing",
  "safe online payments"
];

const Hero: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollY } = useScroll();
  const [chartData, setChartData] = useState(initialChartData);

  // 3D Tilt Effect on scroll
  const rotateX = useTransform(scrollY, [0, 400], [20, 5]); 
  const scale = useTransform(scrollY, [0, 400], [1, 0.95]);
  const opacity = useTransform(scrollY, [0, 600], [1, 0]);

  // Parallax Effects
  const gridY = useTransform(scrollY, [0, 500], [0, 200]);

  // Dynamic Chart Simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setChartData(prevData => {
        return prevData.map(item => ({
          ...item,
          value: Math.max(5, Math.min(15, item.value + (Math.random() - 0.5) * 0.8)) // Random fluctuation
        }));
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);
  
  return (
    <section ref={containerRef} className="relative pt-32 pb-20 overflow-hidden min-h-screen flex flex-col justify-start items-center bg-[#020617] perspective-[2000px]">
      
      {/* --- Background Effects --- */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
          {/* Moving Grid - Made very subtle (opacity-5) */}
          <motion.div 
            style={{ y: gridY }}
            animate={{ backgroundPosition: ["0% 0%", "0% 100%"] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-5"
          />
          
          {/* Central Purple Glow (Behind Dashboard) - Reduced intensity */}
          <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-brand-900/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="max-w-5xl mx-auto px-6 relative z-10 text-center flex flex-col items-center mb-16">
        
        {/* Badge */}
        <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/50 border border-brand-500/20 backdrop-blur-md mb-8 shadow-[0_0_15px_rgba(139,92,246,0.1)]"
        >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-500 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
            </span>
            <span className="text-xs font-medium text-brand-200 tracking-wide">AI-POWERED GROWTH</span>
        </motion.div>

        {/* Headline */}
        <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-5xl md:text-7xl font-display font-bold leading-[1.1] mb-6 tracking-tight text-white drop-shadow-2xl"
        >
            Elevate your visibility <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-300 via-white to-brand-300 animate-gradient-x bg-[length:200%_auto]">
               effortlessly with AI.
            </span>
        </motion.h1>

        {/* Subhead */}
        <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg text-slate-400 max-w-2xl mb-10 leading-relaxed font-light"
        >
            Where smart technology meets user-friendly SEO tools. Build profit engines that scale.
        </motion.p>

        {/* Buttons */}
        <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4"
        >
            <button className="px-8 py-3.5 rounded-full bg-white text-slate-950 font-bold hover:bg-slate-200 transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                Start for free
            </button>
        </motion.div>
      </div>

      {/* --- 3D Dashboard Visual --- */}
      <motion.div
        style={{ 
            rotateX: rotateX,
            scale: scale,
            opacity: opacity,
            transformPerspective: 1200
        }}
        initial={{ opacity: 0, y: 100, rotateX: 30 }}
        animate={{ opacity: 1, y: 0, rotateX: 20 }}
        transition={{ duration: 1, delay: 0.4, ease: "easeOut" }}
        className="w-full max-w-6xl mx-auto px-4 relative z-20"
      >
        <div className="relative rounded-2xl bg-[#0a0a0a] border border-slate-800 shadow-2xl overflow-hidden h-auto md:aspect-[2/1] flex flex-col md:flex-row">
            
            {/* Sidebar (Desktop) */}
            <div className="hidden md:flex flex-col w-64 border-r border-white/5 bg-[#050505] p-4">
                {/* Window Controls (Stealth Mode) */}
                <div className="flex gap-2 mb-8 px-2">
                    <div className="w-3 h-3 rounded-full bg-slate-700"></div>
                    <div className="w-3 h-3 rounded-full bg-slate-700"></div>
                    <div className="w-3 h-3 rounded-full bg-slate-700"></div>
                </div>

                <div className="space-y-1">
                    {[
                        { icon: LayoutDashboard, label: "Site Overview", active: true },
                        { icon: BarChart2, label: "Analytics" },
                        { icon: Zap, label: "Smart Keyword Generator" },
                        { icon: Target, label: "Goals" },
                        { icon: FileText, label: "Content Evaluation" },
                        { icon: Link2, label: "Backlink Audit" },
                        { icon: Search, label: "Link Optimization Wizard" }
                    ].map((item, i) => (
                        <div key={i} className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors cursor-pointer ${item.active ? 'bg-slate-900 text-brand-200 font-medium border border-white/5' : 'text-slate-600 hover:text-slate-400 hover:bg-white/5'}`}>
                            <item.icon className={`w-4 h-4 ${item.active ? 'text-brand-400' : 'text-slate-600'}`} />
                            {item.label}
                        </div>
                    ))}
                </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 bg-[#0a0a0a] flex flex-col min-h-[500px] md:min-h-0">
                
                {/* Dashboard Header */}
                <div className="h-16 border-b border-white/5 flex items-center justify-between px-6 md:px-8">
                    <div className="flex flex-col">
                        <span className="text-white font-semibold text-sm">Site Overview</span>
                        <span className="text-slate-500 text-xs flex items-center gap-1">
                            www.website.com <ArrowUpRight className="w-3 h-3" />
                        </span>
                    </div>
                    <div className="flex items-center gap-4">
                        <div className="hidden md:flex items-center gap-2 bg-slate-900/50 border border-white/5 rounded-lg px-3 py-1.5 text-xs text-slate-400">
                           <Search className="w-3 h-3" />
                           <span>Search</span>
                        </div>
                        <div className="w-8 h-8 rounded-lg bg-brand-600/20 border border-brand-500/20 flex items-center justify-center text-brand-400">
                            <Zap className="w-4 h-4 fill-current" />
                        </div>
                    </div>
                </div>

                {/* Dashboard Body */}
                <div className="p-6 md:p-8 overflow-hidden flex-1 overflow-y-auto">
                    
                    {/* Date Filter */}
                    <div className="flex items-center gap-2 mb-6">
                        <div className="flex items-center gap-2 bg-slate-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-slate-400 cursor-pointer hover:border-brand-500/30 transition-colors">
                            <Calendar className="w-3 h-3 text-brand-500" />
                            <span>Jun 24 <ArrowRight className="inline w-3 h-3 mx-1" /> Today</span>
                        </div>
                    </div>

                    {/* Widgets Grid */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-auto lg:h-[calc(100%-3rem)]">
                        
                        {/* Main Graph Card */}
                        <div className="lg:col-span-2 bg-[#0f0f0f] border border-white/5 rounded-xl p-6 relative group overflow-hidden flex flex-col min-h-[300px]">
                            {/* Card Glow */}
                            <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-brand-900/20 rounded-full blur-3xl pointer-events-none opacity-50"></div>

                            <div className="flex justify-between items-start mb-6 z-10">
                                <div>
                                    <h3 className="text-slate-500 text-xs uppercase tracking-wider font-medium mb-1">Visibility</h3>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-3xl font-display font-bold text-white">
                                          {chartData[chartData.length - 1].value.toFixed(2)}%
                                        </span>
                                        {/* Live Indicator - Switched to Purple Theme */}
                                        <span className="text-brand-300 text-sm font-medium bg-brand-500/20 px-1.5 py-0.5 rounded flex items-center gap-1 border border-brand-500/20">
                                          <motion.span
                                            animate={{ opacity: [0.5, 1, 0.5] }}
                                            transition={{ duration: 2, repeat: Infinity }}
                                            className="w-1.5 h-1.5 rounded-full bg-brand-400 inline-block"
                                          />
                                          Live
                                        </span>
                                    </div>
                                </div>
                                <button className="text-slate-600 hover:text-white transition-colors">
                                    <MoreHorizontal className="w-5 h-5" />
                                </button>
                            </div>

                            {/* Recharts Area */}
                            <div className="flex-1 min-h-[200px] w-full relative z-10">
                                <ResponsiveContainer width="100%" height="100%">
                                    <AreaChart data={chartData}>
                                        <defs>
                                            <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                                                <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                                                <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                                            </linearGradient>
                                        </defs>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} opacity={0.5} />
                                        <XAxis dataKey="name" hide />
                                        <YAxis hide domain={['dataMin - 2', 'dataMax + 2']} />
                                        <Tooltip 
                                            contentStyle={{ backgroundColor: '#0f0f0f', borderColor: '#333', borderRadius: '8px', boxShadow: '0 10px 30px -10px rgba(0,0,0,0.8)' }}
                                            itemStyle={{ color: '#fff', fontSize: '12px' }}
                                            cursor={{ stroke: '#8b5cf6', strokeWidth: 1, strokeDasharray: '4 4' }}
                                        />
                                        <Area 
                                            type="monotone" 
                                            dataKey="value" 
                                            stroke="#8b5cf6" 
                                            strokeWidth={2}
                                            fillOpacity={1} 
                                            fill="url(#colorValue)" 
                                            activeDot={{ r: 4, strokeWidth: 0, fill: '#fff' }}
                                            isAnimationActive={true}
                                            animationDuration={1000}
                                        />
                                    </AreaChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Keywords List Card */}
                        <div className="bg-[#0f0f0f] border border-white/5 rounded-xl p-6 relative flex flex-col min-h-[300px]">
                             <div className="flex justify-between items-start mb-6">
                                <div>
                                    <h3 className="text-slate-500 text-xs uppercase tracking-wider font-medium mb-1">Organic Keywords</h3>
                                    <div className="flex items-baseline gap-2">
                                        <span className="text-3xl font-display font-bold text-white">35.6K</span>
                                        <span className="text-rose-400 text-sm font-medium bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/10">-2.5%</span>
                                    </div>
                                </div>
                                <ChevronDown className="w-5 h-5 text-slate-600" />
                             </div>

                             <div className="flex-1 overflow-hidden">
                                <h4 className="text-xs font-semibold text-slate-600 mb-3 uppercase">Top Keywords</h4>
                                <div className="space-y-3">
                                    {keywords.map((kw, i) => (
                                        <div key={i} className="flex items-center justify-between group cursor-pointer hover:bg-white/5 p-1.5 -mx-1.5 rounded transition-colors">
                                            <div className="flex items-center gap-2 overflow-hidden">
                                                <div className="w-1.5 h-1.5 rounded-full bg-slate-800 group-hover:bg-brand-500 transition-colors"></div>
                                                <span className="text-sm text-slate-400 group-hover:text-white truncate transition-colors">{kw}</span>
                                            </div>
                                            <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                                                <MoreHorizontal className="w-3 h-3 text-slate-500" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
            
            {/* Glossy Overlay */}
            <div className="absolute inset-0 bg-gradient-to-tr from-white/5 via-transparent to-transparent pointer-events-none rounded-2xl"></div>
        </div>
        
      </motion.div>
    </section>
  );
};

export default Hero;